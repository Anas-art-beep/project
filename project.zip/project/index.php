<?php
session_start();

$fixed_id = "admin"; // Fixed ID
$fixed_password = "123456"; // Fixed password

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $password = $_POST['password'];

    if ($id === $fixed_id && $password === $fixed_password) {
        $_SESSION['user_id'] = $id; // Start session
        header("Location: dashboard.php"); // Redirect to dashboard
        exit();
    } else {
        echo "<script>alert('Invalid ID or Password!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online T-Shirt Printing - Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('background.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 100%;
            height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        .header {
            background: rgba(0, 0, 0, 0.7);
            color: white;
            padding: 20px;
            text-align: center;
            width: 100%;
            position: fixed;
            top: 0;
        }
        .login-box {
            background: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .login-box h2 {
            margin-top: 0;
        }
        .login-box input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .login-box button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            background: #5cb85c;
            color: white;
            cursor: pointer;
        }
        .login-box button:hover {
            background: #4cae4c;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Online T-Shirt Printing Project</h1>
    </div>
    <div class="container">
        <div class="login-box">
            <h2>Login</h2>
            <form method="post">
                <input type="text" name="id" placeholder="ID" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Login</button>
            </form>
        </div>
    </div>
</body>
</html>
