<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Design Your T-Shirt</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f0f0;
            text-align: center;
            margin: 0;
            padding: 20px;
        }
        .tshirt-container {
            position: relative;
            display: inline-block;
        }
        .tshirt {
            width: 250px;
        }
        .text-overlay {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 18px;
            font-weight: bold;
            color: black;
            white-space: pre-line; /* Allows multiline text */
            text-align: center;
            max-width: 80%;
        }
        .input-box {
            margin-top: 10px;
        }
        .buy-form {
            display: none;
            margin-top: 20px;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px gray;
            width: 300px;
            margin: auto;
        }
        input, select, textarea {
            width: 100%;
            padding: 8px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        button {
            padding: 10px;
            background: green;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background: darkgreen;
        }
    </style>
</head>
<body>

    <h2>Design Your Own T-Shirt</h2>
    
    <div class="tshirt-container">
        <img src="tshirt.jpg" class="tshirt" alt="T-Shirt">
        <div class="text-overlay" id="tshirtText"></div>
    </div>

    <div class="input-box">
        <textarea id="textInput" placeholder="Enter your text" oninput="updateTShirt()" rows="3"></textarea>
        <label>Choose Text Color:</label>
        <select id="textColor" onchange="updateTextColor()">
            <option value="black">Black</option>
            <option value="white">White</option>
            <option value="red">Red</option>
            <option value="blue">Blue</option>
            <option value="green">Green</option>
        </select>
    </div>

    <button id="buyNowBtn" style="display:none;" onclick="showForm()">Buy Now (₹599)</button>

    <div class="buy-form" id="buyForm">
        <h3>Enter Your Details</h3>
        <p><strong>Amount: ₹599</strong></p>
        <form onsubmit="return validateForm()">
            <input type="text" id="name" placeholder="Enter your name">
            <input type="text" id="address" placeholder="Enter your address">
            <input type="text" id="pincode" placeholder="Enter your pincode">
            <button type="submit">Confirm Purchase</button>
        </form>
        <p id="successMsg" style="color:green; display:none;">Purchase Successful! 🎉</p>
    </div>

    <script>
        function updateTShirt() {
            let text = document.getElementById("textInput").value;
            document.getElementById("tshirtText").innerText = text;
            document.getElementById("buyNowBtn").style.display = text.trim() ? "block" : "none";
        }

        function updateTextColor() {
            let color = document.getElementById("textColor").value;
            document.getElementById("tshirtText").style.color = color;
        }

        function showForm() {
            document.getElementById("buyForm").style.display = "block";
        }

        function validateForm() {
            let name = document.getElementById("name").value.trim();
            let address = document.getElementById("address").value.trim();
            let pincode = document.getElementById("pincode").value.trim();
            let namePattern = /^[A-Za-z\s]+$/;
            let pincodePattern = /^[0-9]{6}$/;

            if (!name.match(namePattern)) {
                alert("Name should contain only letters!");
                return false;
            }
            if (address.length < 5) {
                alert("Address is too short!");
                return false;
            }
            if (!pincode.match(pincodePattern)) {
                alert("Pincode must be a 6-digit number!");
                return false;
            }

            document.getElementById("successMsg").style.display = "block";
            return false; // Prevents form submission (for demo)
        }
    </script>

</body>
</html>
