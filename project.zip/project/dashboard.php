<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Online T-Shirt Printing</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('background.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            color: white;
        }
        .header {
            background: rgba(0, 0, 0, 0.7);
            padding: 20px;
            text-align: center;
        }
        .header h1 {
            margin: 0;
        }
        .navbar {
            background: #333;
            overflow: hidden;
            text-align: center;
        }
        .navbar a {
            display: inline-block;
            color: white;
            padding: 14px 20px;
            text-decoration: none;
        }
        .navbar a:hover {
            background: #ddd;
            color: black;
        }
        .content {
            text-align: center;
            padding: 50px;
        }
        .tshirt-options {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }
        .tshirt-options div {
            margin: 0 20px;
            text-align: center;
        }
        .tshirt-options img {
            width: 250px;
            height: auto;
            cursor: pointer;
        }
        .logout {
            text-align: center;
            margin-top: 20px;
        }
        .logout button {
            background: red;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Online T-Shirt Printing</h1>
        <button style="background-color: pink; border: none; padding: 10px; cursor: pointer;">Shop Now</button>
    </div>
    <div class="navbar">
        <a href="dashboard.php">Home</a>
        <a href="#">Buy T-Shirt</a>
        <a href="design.php">Design T-Shirt</a>
        <a href="about.php">About Us</a>
        <a href="contact.php">Contact Us</a>
        <a href="logout.php">Logout</a>
    </div>
    <div class="content">
        <img src="model.jpg" alt="T-Shirt Model">
        <div class="tshirt-options">
            <div>
                <a href="choose-design.php">
                    <img src="choosedesign.jpg" alt="Choose From Our Designs">
                </a>
                <p>Choose From Our Designs</p>
            </div>
            <div>
                <a href="design.php">
                    <img src="createdesign.jpg" alt="Create Your Own Design">
                </a>
                <p>Create Your Own Design</p>
            </div>
        </div>
    </div>
    <div class="logout">
        <form action="logout.php" method="post">
            <button type="submit">Logout</button>
        </form>
    </div>
</body>
</html>
