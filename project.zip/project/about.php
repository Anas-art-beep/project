<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Online T-Shirt Printing</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 0;
            color: #333;
        }
        .container {
            width: 80%;
            margin: auto;
            padding: 50px;
            background: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .navbar {
            background: #333;
            padding: 15px;
            text-align: center;
        }
        .navbar a {
            color: white;
            padding: 10px 15px;
            text-decoration: none;
        }
        .navbar a:hover {
            background: #ddd;
            color: black;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="dashboard.php">Home</a>
        <a href="about.php">About Us</a>
        <a href="contact.php">Contact Us</a>
        <a href="logout.php">Logout</a>
    </div>
    <div class="container">
        <h1>About Us</h1>
        <p>We are an online T-shirt printing platform that allows customers to design and purchase their own custom T-shirts.</p>
        <p>Our mission is to provide high-quality, personalized clothing at affordable prices.</p>
    </div>
</body>
</html>
